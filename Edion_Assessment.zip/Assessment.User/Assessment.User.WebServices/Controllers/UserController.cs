using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assessment.User.BusinessDomain;
using Assessment.User.DataAccess;
using Assessment.User.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assessment.User.WebServices.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  [Authorize]
  public class UserController : ControllerBase
  {
     
    public readonly IUserBL _UserBL;
    public UserController(IUserBL userBL)
    {
       
      _UserBL = userBL;
    }

    [HttpGet]
    [Route("GetUser/{userName}")]
    public IActionResult GetUser(string userName)
    { 
      var response = _UserBL.GetUser(userName);
      if (response == null)
        return NotFound($"{userName} not found");
      return Ok(response);
    }

    [AllowAnonymous]
    [HttpPost]
    [Route("AddUser")]
    public IActionResult AddUser(UserRequest userRequest)
    {
      var response= _UserBL.SaveUser(userRequest);

      if (response)
        return Ok();
      return BadRequest();
    }
    [HttpPut]
    [Route("UpdateUser")]
    public IActionResult UpdateUser(UserRequest userRequest)
    {
      var response = _UserBL.UpdateUser(userRequest);

      if (response)
        return Ok();
      return BadRequest();
    }

    [HttpDelete]
    [Route("DeleteUser/{userName}")]
    public IActionResult DeleteUser(string userName)
    {
      var response = _UserBL.DeleteUser(userName);
      if (response)
        return Ok();
      return BadRequest();
    }
  }
}
