using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Assessment.User.BusinessDomain;
using Assessment.User.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Assessment.User.WebServices.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class LoginController : ControllerBase
  {
    private readonly ILoginBL _LoginBL;

    public LoginController(ILoginBL loginBL)
    {
      _LoginBL = loginBL;
    }
    [AllowAnonymous]
    [HttpPost]
    public IActionResult Login([FromBody] LoginRequest loginUser)
    {
      var jwttoken = _LoginBL.ValidateUser(loginUser);      
      if (string.IsNullOrEmpty(jwttoken))
        return Unauthorized();

      return Ok(new { token = jwttoken, });      
    }   
  }
}
