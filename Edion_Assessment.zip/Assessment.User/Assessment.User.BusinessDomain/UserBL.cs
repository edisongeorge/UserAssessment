using Assessment.User.DataAccess;
using Assessment.User.DataAccess.Entity;
using Assessment.User.Model;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Linq.Expressions;

namespace Assessment.User.BusinessDomain
{
  public class UserBL :IUserBL
  {
    public readonly IUserDbcontext _UserDbcontext;
    public UserBL(IUserDbcontext userDbcontext)
    {
      _UserDbcontext = userDbcontext;
    }
    public bool SaveUser(UserRequest userRequest)
    {
      try
      {
        var user = new Users
        {
          UserId = userRequest.UserName,
          Pcode =Common.EncodedText(userRequest.Password),
          FirstName = userRequest.FirstName,
          LastName=userRequest.LastName,
          Email=userRequest.Email,
          IsActive=true     
        };
        _UserDbcontext.Users.Add(user);
        _UserDbcontext.SaveChanges();
        return true;
      }
      catch(Exception ex)
      {
        //Loging 
        return false;
      }      
    }

    public bool UpdateUser(UserRequest userRequest)
    {
      try
      {
        var user = _UserDbcontext.Users.FirstOrDefault(x => x.UserId.Equals(userRequest.UserName));
        if (user != null)
        {
          user.Pcode = Common.EncodedText(userRequest.Password);
          user.FirstName = userRequest.FirstName;
          user.LastName = userRequest.LastName;
          user.Email = userRequest.Email;
          user.IsActive = userRequest.IsActive;
          _UserDbcontext.SaveChanges();
        }       
        return true;
      }
      catch (Exception ex)
      {
        //Loging 
        return false;
      }
    }
    public UserRequest ValidateUser(LoginRequest loginUser)
    {
      try
      {
        var response = new UserRequest();
        var user = _UserDbcontext.Users.FirstOrDefault(x => x.UserId.Equals(loginUser.UserName) && x.Pcode.Equals(Common.EncodedText(loginUser.Password)));
        if (user == null)
          return null;

        response.UserName = user.UserId;
        response.FirstName = user.FirstName;
        response.LastName = user.LastName;
        response.Email = user.Email;
        return response;

      }
      catch(Exception ex)
      {
        throw ex;

      }
    }

    public bool DeleteUser(string userName)
    {
      try
      {
        var user = _UserDbcontext.Users.FirstOrDefault(x => x.UserId.Equals(userName));
        if (user != null)
        {
          user.IsActive = false;
          _UserDbcontext.SaveChanges();          
        }
        return true;
      }
      catch(Exception ex)
      {
        throw ex;
      }
    }

    public UserRequest GetUser(string userName)
    {
      var response = new UserRequest();
      var user = _UserDbcontext.Users.FirstOrDefault(x => x.UserId.Equals(userName));
      if (user == null)
        return null;

      response.UserName = user.UserId;
      response.FirstName = user.FirstName;
      response.LastName = user.LastName;
      response.Email = user.Email;
      return response;
    }
  }
}
