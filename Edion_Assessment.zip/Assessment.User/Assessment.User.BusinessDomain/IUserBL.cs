using Assessment.User.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment.User.BusinessDomain
{
  public interface IUserBL 
  {
    bool SaveUser(UserRequest userRequest);
    UserRequest ValidateUser(LoginRequest loginUser);
    bool UpdateUser(UserRequest userRequest);
    bool DeleteUser(string userName);
    UserRequest GetUser(string userName);
  }
}
