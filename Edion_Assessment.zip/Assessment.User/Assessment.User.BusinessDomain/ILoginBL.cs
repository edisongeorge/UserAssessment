using Assessment.User.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment.User.BusinessDomain
{
  public interface ILoginBL
  {
    string ValidateUser(LoginRequest user);
  }
}
