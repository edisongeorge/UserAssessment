using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Assessment.User.BusinessDomain
{
 public static class Common
  {
   public static string EncodedText(string plainText)
    {
      using SHA256 hash = SHA256.Create();
      byte[] bytes = hash.ComputeHash(Encoding.UTF8.GetBytes(plainText));
      StringBuilder encodetext = new StringBuilder();
      for (int i = 0; i < bytes.Length; i++)
      {
        encodetext.Append(bytes[i].ToString("x2"));
      }
      return encodetext.ToString();
    }
  }
}
