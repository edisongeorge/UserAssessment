using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Assessment.User.DataAccess.Entity;

namespace Assessment.User.DataAccess
{
  public class UserDbcontext : DbContext,IUserDbcontext
  {
    public UserDbcontext(DbContextOptions<UserDbcontext> dbContextOptions):base(dbContextOptions)
    {

    }
    public DbSet<Users> Users { get; set; }
  
  }
}
