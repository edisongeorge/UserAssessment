using Assessment.User.DataAccess.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment.User.DataAccess
{
  public interface IUserDbcontext
  {
    DbSet<Users> Users { get; set; }
    int SaveChanges();
  }
}
