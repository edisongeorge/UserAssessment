using Assessment.User.BusinessDomain;
using Assessment.User.Model;
using Assessment.User.WebServices.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;

namespace Assessment.user.Test
{   
  public class UserControllerTest
  {
    private Mock<IUserBL> _Mock;
    private UserController _Controller;
    [SetUp]
    public void Setup()
    {
      _Mock = new Mock<IUserBL>();
      _Controller = new UserController(_Mock.Object);
    }

    [Test]
    public void IsGetUserReturning200Ok()
    {
      //Arrange
      var resonse = new UserRequest
      {
        UserName = "Edison",
        Password = "",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      //Act
      _Mock.Setup(p => p.GetUser("Edison")).Returns(resonse);      
      var result = _Controller.GetUser("Edison") as OkObjectResult;
      //Assert
      Assert.AreEqual(200, result.StatusCode);
    }

    [Test]
    public void IsGetUserReturningNotFound()
    {
      //Arrange
      UserRequest response = null;      
      //Act
      _Mock.Setup(p => p.GetUser("Edison")).Returns(response);       
      var result = _Controller.GetUser("Edison") as NotFoundObjectResult;
      //Assert
      Assert.AreEqual(404, result.StatusCode);
    }

    [Test]
    public void IsAddUserReturning200Ok()
    {
      //Arrange
      var request = new UserRequest
      {
        UserName = "Edison",
        Password = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      //Act
      _Mock.Setup(p => p.SaveUser(request)).Returns(true);    
      var result = _Controller.AddUser(request) as OkResult;
      //Assert
      Assert.AreEqual(200, result.StatusCode);
    }

    [Test]
    public void IsAddUserReturning400Badrequest()
    {
      //Arrange
      var request = new UserRequest
      {
        UserName = "",
        Password = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      //Act
      _Mock.Setup(p => p.SaveUser(request)).Returns(false);
       var result = _Controller.AddUser(request) as BadRequestResult;
      //Assert
      Assert.AreEqual(400, result.StatusCode);
    }

    [Test]
    public void IsUpdateUserReturning200Ok()
    {
      //Arrange
      var request = new UserRequest
      {
        UserName = "Edison",
        Password = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };

      //Act
      _Mock.Setup(p => p.UpdateUser(request)).Returns(true);     
      var result = _Controller.UpdateUser(request) as OkResult;
      //Assert
      Assert.AreEqual(200, result.StatusCode);
    }

    [Test]
    public void IsUpdateUserReturning400Badrequest()
    {
      //Arrange
      var request = new UserRequest
      {
        UserName = "",
        Password = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };       
      //Act
      _Mock.Setup(p => p.UpdateUser(request)).Returns(false);    
      var result = _Controller.UpdateUser(request) as BadRequestResult;
      //Assert
      Assert.AreEqual(400, result.StatusCode);
    }

    [Test]
    public void IsDeleteUserReturning200Ok()
    {
      //Act
      _Mock.Setup(p => p.DeleteUser("Edison")).Returns(true);      
      var result = _Controller.DeleteUser("Edison") as OkResult;
      //Assert
      Assert.AreEqual(200, result.StatusCode);
    }

    [Test]
    public void IsDeleteUserReturning400Badrequest()
    {
      //Arrange      

      //Act
      _Mock.Setup(p => p.DeleteUser("Edison")).Returns(false);     
      var result = _Controller.DeleteUser("Edison") as BadRequestResult;
      //Assert
      Assert.AreEqual(400, result.StatusCode);
    }
  }
}
