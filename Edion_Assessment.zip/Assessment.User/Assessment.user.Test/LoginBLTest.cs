using Assessment.User.BusinessDomain;
using Assessment.User.DataAccess;
using Assessment.User.DataAccess.Entity;
using Assessment.User.Model;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;

namespace Assessment.user.Test
{
  public class LoginBLTest
  {
    private Mock<IConfiguration> _Config;
    private Mock<IUserBL> _MockUserBL;
    private LoginBL _LoginBL;

    [SetUp]
    public void Setup()
    {
      _Config = new Mock<IConfiguration>();
      _MockUserBL = new Mock<IUserBL>();
      _LoginBL = new LoginBL(_Config.Object, _MockUserBL.Object);
    }

    [Test]
    [Ignore("")]
    public void GenerateTokenTest()
    {
      var request = new LoginRequest
      {
        UserName = "edison",
        Password = "password"
      };

      var response = new UserRequest
      {
        UserName = "edison",
        Password = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      //Mock<IConfigurationSection> mockSection = new Mock<IConfigurationSection>();
      //mockSection.Setup(x => x.Value).Returns("test");
      _Config.Setup(x => x["Jwt:Key"]).Returns("Test");
      _Config.Setup(x => x["Jwt:Issuer"]).Returns("Test.com");      
      _MockUserBL.Setup(x => x.ValidateUser(request)).Returns(response);
      var result = _LoginBL.ValidateUser(request);

      Assert.IsNotEmpty(result);
    }

  }
}
