using Assessment.User.BusinessDomain;
using Assessment.User.DataAccess;
using Assessment.User.DataAccess.Entity;
using Assessment.User.Model;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
namespace Assessment.user.Test
{
  public class UserBLTest
  {
    private Mock<IUserDbcontext> _Mock;
    private UserBL _UserBL;
    //private DbContextOptions<UserDbcontext> dbContextOptions;

    [SetUp]
    public void Setup()
    {     
      _Mock = new Mock<IUserDbcontext>();
      _UserBL = new UserBL(_Mock.Object);
    }
    [Test]
    public void ReturnValidUser()
    {
      List<Users> users = new List<Users>();      
      var user = new Users
      {
        UserId = "Edison",
        Pcode = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      users.Add(user);
      _Mock.Setup(x => x.Users).Returns(DbContextMock.GetQueryableMockDbSet<Users>(users));
      var result = _UserBL.GetUser("Edison");

      Assert.AreEqual(user.FirstName, result.FirstName);
    }

    [Test]
    public void ValidateUserTest()
    {
      var request = new LoginRequest
      {
        UserName="edison",
        Password= "password"
      };

      List<Users> users = new List<Users>();
      var user = new Users
      {
        UserId = "edison",
        Pcode = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      users.Add(user);
      _Mock.Setup(x => x.Users).Returns(DbContextMock.GetQueryableMockDbSet<Users>(users));
      var result = _UserBL.ValidateUser(request);

      Assert.AreEqual(user.FirstName, result.FirstName);
    }

    [Test]
    public void DeleteUserTest()
    {
      List<Users> users = new List<Users>();
      var user = new Users
      {
        UserId = "edison",
        Pcode = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      users.Add(user);
      _Mock.Setup(x => x.Users).Returns(DbContextMock.GetQueryableMockDbSet<Users>(users));
      var result = _UserBL.DeleteUser("edison");

      Assert.IsTrue(result);
    }

    [Test]
    public void SaveUserTest()
    {
      var request = new UserRequest
      {
        UserName = "edison",
        Password = "password",
        FirstName="Test",
        LastName="Test",
        Email= "test@test.com"
      };

      List<Users> users = new List<Users>();
      var user = new Users
      {
        UserId = "edison",
        Pcode = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      users.Add(user);
      _Mock.Setup(x => x.Users).Returns(DbContextMock.GetQueryableMockDbSet<Users>(users));
      var result = _UserBL.SaveUser(request);

      Assert.IsTrue(result);
    }

    [Test]
    public void UpdateUserTest()
    {
      var request = new UserRequest
      {
        UserName = "edison",
        Password = "password",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };

      List<Users> users = new List<Users>();
      var user = new Users
      {
        UserId = "edison",
        Pcode = "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
        FirstName = "Test",
        LastName = "Test",
        Email = "test@test.com"
      };
      users.Add(user);
      _Mock.Setup(x => x.Users).Returns(DbContextMock.GetQueryableMockDbSet<Users>(users));
      var result = _UserBL.UpdateUser(request);

      Assert.IsTrue(result);
    }
  }
}
