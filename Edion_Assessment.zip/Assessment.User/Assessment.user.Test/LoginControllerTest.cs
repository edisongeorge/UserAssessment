using Assessment.User.BusinessDomain;
using Assessment.User.Model;
using Assessment.User.WebServices.Controllers;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace Assessment.user.Test
{
  public class LoginControllerTest
  {
    private Mock<ILoginBL> _Mock;
    private LoginController _Controller;
    [SetUp]
    public void Setup()
    {
      _Mock = new Mock<ILoginBL>();
      _Controller = new LoginController(_Mock.Object);
    }

    [Test]
    public void IsGetUserReturning200Ok()
    {
      //Arrange
      var request = new LoginRequest
      {
        UserName = "Edison",
        Password = "password",        
      };

      //Act
      _Mock.Setup(p => p.ValidateUser(request)).Returns("token");     
      var result = _Controller.Login(request) as OkObjectResult;
      //Assert
      Assert.AreEqual(200, result.StatusCode);
    }

    [Test]
    public void IsGetUserReturning401Unauthorized()
    {
      //Arrange
      var request = new LoginRequest
      {
        UserName = "Edison",
        Password = "",
      };
      //Act
      _Mock.Setup(p => p.ValidateUser(request)).Returns(string.Empty);      
      var result = _Controller.Login(request) as UnauthorizedResult;
      //Assert
      Assert.AreEqual(401, result.StatusCode);
    }
  }
}
