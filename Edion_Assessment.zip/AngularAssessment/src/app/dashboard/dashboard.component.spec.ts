import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientModule} from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { ToastrModule } from 'ngx-toastr';
import { Router } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { AuthService } from '../user/auth.service';
import { of } from 'rxjs';

describe('DashboardComponent', () => {
  let mockAuthservice;
  let mocktoasterservice;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let toasterServiceSpy: jasmine.Spy;


  beforeEach(async () => {
    mockAuthservice=jasmine.createSpyObj(['getuser','deleteUser']);
    mockAuthservice.getuser.and.returnValue(of([]));
    mocktoasterservice=jasmine.createSpyObj(['success','error']);

    await TestBed.configureTestingModule({
      declarations: [ DashboardComponent ],
      imports:[HttpClientModule,ToastrModule.forRoot()],
      providers:[{provide:AuthService,useValue:mockAuthservice},{provide:ToastrService,userValue:mocktoasterservice},{provide:Router,useValue:mockRouter}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });


});
