import { Component, OnInit } from '@angular/core';
import { AuthService } from '../user/auth.service';
import { IUser } from '../user/user.model';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  userDetails! :IUser;

  constructor(private authservice:AuthService,private toasterService:ToastrService,private router:Router) { }

  ngOnInit(): void {

    this.authservice.getuser(sessionStorage.getItem('loggedInUser')!).subscribe(response=>{
      this.userDetails={
        userName:response.userName,
        password:'',
        firstName:response.firstName,
        lastName:response.lastName,
        email:response.email
      }
    })

  }

  deleteUser(){
    this.authservice.deleteUser(this.userDetails?.userName).subscribe(response=>{
this.toasterService.success('Deleted Successfully');
    })
  }

  update(){
    this.router.navigate(['/user/profile']);
  }

}
