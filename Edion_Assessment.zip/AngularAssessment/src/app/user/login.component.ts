import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { IUser } from './user.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username!:FormControl;
  password!:FormControl;
  LoginForm!:FormGroup;
  isInvalidUser=false;
  constructor(private authService:AuthService,private router: Router ,private toasterService:ToastrService) { }

  ngOnInit(): void {
    this.username=new FormControl('',Validators.required);
    this.password= new FormControl('',Validators.required);
    this.LoginForm=new FormGroup({
      username:this.username,
      password:this.password
    })
  }

  validateUser() {
    return this.username.valid || this.username.untouched
  }

  validatePassword() {
    return this.password.valid || this.password.untouched
  }

  login(loginformValue:any){
    this.authService.loginUser(loginformValue.username, loginformValue.password).subscribe(response=>{
      if(response){
       sessionStorage.setItem('loggedInUser',loginformValue.username);
       this.isInvalidUser=true
       sessionStorage.setItem('token',response.token);
       this.router.navigate(['dashboard']);
      }
    },error=>{
      this.isInvalidUser=false;
this.toasterService.warning('Username or password is wrong');
    });

  }

  signup(){
    this.router.navigate(['/user/profile']);
  }

}
