import { Injectable } from '@angular/core';
import { IUser } from './user.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  currentUser!: IUser
  constructor(private http:HttpClient) { }

  loginUser(userName: string, password: string):Observable<any> {
    let loginInfo = { username: userName, password: btoa(password) }
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };

    return this.http.post(`${environment.baseurl}/api/login`,loginInfo,options);
  }

  updateUser(user:IUser) {
    let options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post(`${environment.baseurl}/api/user/AddUser`,user,options);

  }

  getuser(userName:string):Observable<any>{
   return this.http.get(`${environment.baseurl}/api/user/GetUser/${userName}`);
  }

  deleteUser(userName:string){
    return this.http.delete(`${environment.baseurl}/api/user/DeleteUser/${userName}`);
  }
}
