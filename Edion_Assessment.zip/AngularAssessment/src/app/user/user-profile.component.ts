import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { IUser } from './user.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  username!: FormControl;
  password!: FormControl;
  firstName!: FormControl;
  lastName!: FormControl;
  email!: FormControl;
  profileform!: FormGroup;
  currentUser!:IUser;

  constructor(private authService: AuthService,
    private route: Router,private toasterservice:ToastrService) { }

  ngOnInit(): void {
    if(sessionStorage.getItem('loggedInUser'))
    {
      this.authService.getuser(sessionStorage.getItem('loggedInUser')!).subscribe(response=>{
        this.currentUser={
          userName:response.userName,
          password:'',
          firstName:response.firstName,
          lastName:response.lastName,
          email:response.email
        }

        this.username = new FormControl(this.currentUser.userName,Validators.required);
        this.password = new FormControl('',Validators.required);
        this.firstName = new FormControl(this.currentUser.firstName,Validators.required);
        this.lastName = new FormControl(this.currentUser.lastName, Validators.required);
        this.email=new FormControl(this.currentUser.email);

        this.profileform = new FormGroup({
          username:this.username,
          password:this.password,
          firstName: this.firstName,
          lastName: this.lastName,
          email:this.email
        })
      })

    }
    else
    {
    this.username = new FormControl(this.currentUser.userName,Validators.required);
    this.password = new FormControl('',Validators.required);
    this.firstName = new FormControl(this.currentUser.firstName,Validators.required);
    this.lastName = new FormControl(this.currentUser.lastName, Validators.required);
    this.email=new FormControl(this.currentUser.email);

    this.profileform = new FormGroup({
      username:this.username,
      password:this.password,
      firstName: this.firstName,
      lastName: this.lastName,
      email:this.email
    })
  }
  }

  validateFirstName() {
    return this.firstName.valid || this.firstName.untouched
  }

  validateLastName() {
    return this.lastName.valid || this.lastName.untouched
  }

  saveUserProfile(profileformvalue: any) {
    if (this.profileform.valid) {
     let currentUser:IUser = {
      userName:profileformvalue.username,
      password:profileformvalue.password,
      firstName:profileformvalue.firstName,
     lastName:profileformvalue.lastName,
     email:profileformvalue.email
    }
      this.authService.updateUser(currentUser)
        .subscribe(() => {
          this.toasterservice.success('Saved successfully');
          setTimeout(() => {
            this.route.navigate(['/user/login']);
          }, 500);
        },error=>{
          this.toasterservice.error('Failed to save');
        });

    }
  }

  cancel() {
    this.route.navigate(['dashboard']);
  }

}
