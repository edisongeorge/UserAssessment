import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthService } from './auth.service';
import { HttpClientModule} from '@angular/common/http';
import { UserProfileComponent } from './user-profile.component';
import { ToastrService } from 'ngx-toastr';
import { ToastrModule } from 'ngx-toastr';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import {  FormGroup, ReactiveFormsModule } from '@angular/forms';


describe('UserProfileComponent', () => {
  let component: UserProfileComponent;
  let mockAuthservice;
  let mocktoasterservice;
  let fixture: ComponentFixture<UserProfileComponent>;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  beforeEach(async () => {
    mockAuthservice=jasmine.createSpyObj(['updateUser','getuser']);
    mockAuthservice.updateUser.and.returnValue(of([]));
    mockAuthservice.getuser.and.returnValue(of([]));
    mocktoasterservice=jasmine.createSpyObj(['success','error']);

    await TestBed.configureTestingModule({
      declarations: [ UserProfileComponent ],
      imports:[ReactiveFormsModule,HttpClientModule,ToastrModule.forRoot()],
      providers:[{provide:AuthService,useValue:mockAuthservice},
      {provide:ToastrService,userValue:mocktoasterservice},{provide:Router,useValue:mockRouter}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProfileComponent);
    component = fixture.componentInstance;
    component.currentUser={userName:'',password:'', firstName:'',lastName:'',email:''}
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create a formgroup comprise of formcontrol',()=>{
    component.ngOnInit();
    expect(component.profileform instanceof FormGroup).toBe(true);
      });

      it('should be able to save the userprofile',()=>{
    component.profileform.controls['username'].setValue('edison');
    component.profileform.controls['password'].setValue('test');
    component.profileform.controls['firstName'].setValue('test');
    component.profileform.controls['lastName'].setValue('test');
    component.profileform.controls['email'].setValue('test@test.com');
    component.saveUserProfile(component.profileform);
    expect(component.profileform.valid).toBe(true);
      });
});
