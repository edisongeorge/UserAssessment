// import { TestBed } from '@angular/core/testing';
// import { HttpClientModule} from '@angular/common/http';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;
  let mockhttp;
  beforeEach(() => {
    // TestBed.configureTestingModule({
    //   imports:[HttpClientModule]
    // });
    // service = TestBed.inject(AuthService);
    mockhttp= jasmine.createSpyObj('mockhttp',['delete','post'])
    service= new AuthService(mockhttp);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  // it('should be call http.delete with right API URL',()=>{
  //   mockhttp= jasmine.createSpyObj('mockhttp',['delete'])
  //   mockhttp.delete.and.returnValue(of(false));
  //   service.deleteUser('edison')
  //   expect(mockhttp.delete).toHaveBeenCalledWith(`${environment.baseurl}/api/user/DeleteUser/edison`)

  // });

});
