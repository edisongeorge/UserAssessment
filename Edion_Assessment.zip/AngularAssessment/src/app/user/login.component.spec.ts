import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { ToastrModule } from 'ngx-toastr';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { LoginComponent } from './login.component';
import { of, throwError } from 'rxjs';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let mockAuthservice;
  let mocktoasterservice;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };
  beforeEach(async () => {
    mockAuthservice=jasmine.createSpyObj(['loginUser']);
    mockAuthservice.loginUser.and.returnValue(of([]));

    mocktoasterservice=jasmine.createSpyObj(['warning']);

    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports:[ReactiveFormsModule,HttpClientModule,ToastrModule.forRoot()],
      providers:[{provide:AuthService,useValue:mockAuthservice},
        {provide:ToastrService,userValue:mocktoasterservice},{provide:Router,useValue:mockRouter}]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create a formgroup comprise of formcontrol',()=>{
component.ngOnInit();
expect(component.LoginForm instanceof FormGroup).toBe(true);
  });

  it('should be Validdate the user and allow to login',()=>{
component.LoginForm.controls['username'].setValue('edison');
component.LoginForm.controls['password'].setValue('test');
component.login(component.LoginForm);
mockAuthservice= jasmine.createSpyObj(['loginUser']);
mockAuthservice.loginUser.and.returnValue(of([]));
expect(component.isInvalidUser).toBe(true);
  });


});
