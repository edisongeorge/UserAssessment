import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import {ReactiveFormsModule} from '@angular/forms'
import {userRoutes} from './user.route';
import { RouterModule } from '@angular/router';

import { LoginComponent } from './login.component';
import { UserProfileComponent } from './user-profile.component';


@NgModule({
  declarations: [
    LoginComponent,
    UserProfileComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(userRoutes)

  ]
})
export class UserModule { }
