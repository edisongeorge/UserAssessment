import { NgModule } from '@angular/core';
import {  ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ValidateuserGuard } from './validateuser.guard';


const routes: Routes = [
  { path: 'user', loadChildren: './user/user.module#UserModule' },
  {path:'dashboard',component:DashboardComponent,canActivate:[ValidateuserGuard]},
  {path:'',component:DashboardComponent,canActivate:[ValidateuserGuard]}
];

@NgModule({
  imports: [
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
