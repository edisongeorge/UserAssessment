import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { ValidateuserGuard } from './validateuser.guard';

describe('ValidateuserGuard', () => {
  let guard: ValidateuserGuard;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[{provide:Router,useValue:mockRouter}]
    });
    guard = TestBed.inject(ValidateuserGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
