with final as (
  Select 
    PolicyNumber, 
    case when ContractStatus == 'T' Then 'Terminated' when ContractStatus == 'S' Then 'Suspended' else 'Active' End as ContractStatus, 
    case when Type == 'T' Then 'Term' else 'Permanent Life' End as Type, 
    Premium, 
    case When ContractStatus == 'T' then 0 else DeathBenefit end as DeathBenefit, 
    case when ContractStatus == 'S' then 0 else COALESCE(CashValue, 0) end as CashValue 
  from 
    Policy 
    Left join Benefit On Policy.PolicyNumber = Benefit.PloicyNumber
) 
select 
  PolicyNumber, 
  ContractStatus, 
  Type, 
  Premium, 
  SUM(DeathBenefit) as DeathBenefit, 
  SUM(CashValue) as Cashvalue, 
  (
    SUM(DeathBenefit) + SUM(CashValue)
  ) as FinalValue 
from 
  final 
group by 
  PolicyNumber, 
  ContractStatus, 
  Type, 
  Premium
